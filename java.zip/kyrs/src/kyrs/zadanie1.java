package kyrs;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.MaskFormatter;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class zadanie1 {

	private JFormattedTextField p1;
	private JFormattedTextField p2;
	private JFormattedTextField p3;
	private JFormattedTextField p4;
	private JTextField p5;
	private JButton b1;
	private JButton b2;
	private JLabel l1;
	private JLabel l2;
	private JLabel l3;
	private JLabel l4;
	private JLabel l5;
	private JTextPane pp1;
	JFrame mainframe1;
	static int number = 1;
	
	public zadanie1(int number)
	{
		zadanie1.number = number;
		init();
		}

	private void init()
	{
		this.mainframe1 = new JFrame("������� �1");
		this.mainframe1.setVisible(true);
	    this.mainframe1.setSize(800, 400);
	    MaskFormatter format = null;
	    try
	    {
	      format = new MaskFormatter("#.#");
	    }
	    catch (ParseException localParseException) {}
	    MaskFormatter format1 = null;
	    try
	    {
	      format1 = new MaskFormatter("##");
	    }
	    catch (ParseException localParseException1) {}
	    this.p1 = new JFormattedTextField(format);
	    this.p1.setBounds(40, 30, 180, 30);
	    this.mainframe1.getContentPane().add(this.p1);
	    this.p2 = new JFormattedTextField(format);
	    this.p2.setBounds(40, 70, 180, 30);
	    this.mainframe1.getContentPane().add(this.p2);
	    this.p3 = new JFormattedTextField(format1);
	    this.p3.setBounds(40, 110, 180, 30);
	    this.mainframe1.getContentPane().add(this.p3);
	    this.p4 = new JFormattedTextField(format1);
	    this.p4.setBounds(40, 150, 180, 30);
	    this.mainframe1.getContentPane().add(this.p4);
	    this.p5 = new JTextField(10);
	    this.p5.setBounds(40, 190, 180, 30);
	    this.mainframe1.getContentPane().add(this.p5);
	    this.p5.setVisible(true);
	    this.p5.setEditable(false);
	    this.b1 = new JButton("������");
	    this.b1.setBounds(40, 230, 180, 30);
	    this.mainframe1.getContentPane().add(this.b1);  	    
	    this.b1.addActionListener(new ActionListener() {	    	  
	    	  public void actionPerformed(ActionEvent e) {   	    		    		    
	    		    double a1 = Double.valueOf(p1.getText()).doubleValue();
	    		    double b1 = Double.valueOf(p2.getText()).doubleValue();
	    		    p5.setVisible(true);
	    		    p5.setText(String.valueOf(a1 + b1));
	    		    mainframe1.getContentPane().repaint();
	    		    double qq1 = Double.valueOf(p3.getText()).doubleValue();
	    		    double qq2 = Double.valueOf(p4.getText()).doubleValue();
	    		    double L1 = Double.valueOf(p5.getText()).doubleValue();
	    		    double c3 = L1 / 20;
	    		    pp1.setText(pp1.getText() + "X= " + "		�������� �������:\n");	    		    
	    		    double xx1=0;	      		        		    
	    		    for (xx1=0;xx1<=L1;xx1=xx1+c3)
	    		    {
	    		    	if(xx1<=a1)
	    		    	{
	    		    	
	    		    	double zz1 = (double)((-qq1*Math.pow(xx1, 2))/(2*L1));
	    		    	double newxx1 = new BigDecimal(xx1).setScale(3, RoundingMode.UP).doubleValue();
	    		    	double newzz1 = new BigDecimal(zz1).setScale(4, RoundingMode.UP).doubleValue();
	    		    	pp1.setText(pp1.getText() + newxx1 + "		" + newzz1 + "\n");
	    		    	} 
	    		    	else 
	    		    	{	    		    		 		    		
	    		    		double zz2= (double)((-qq1*Math.pow(xx1, 2))/(2*L1)-(qq2*(b1/Math.PI)*(1-Math.cos(Math.PI*(xx1-a1)/b1))));
	    		    		double newxx1 = new BigDecimal(xx1).setScale(3, RoundingMode.UP).doubleValue();
	    		    		double newzz2 = new BigDecimal(zz2).setScale(4, RoundingMode.UP).doubleValue();
	    		    		pp1.setText(pp1.getText() +  newxx1 + "		" + newzz2 + "\n");	    		    	
	    		    	}    		    	
	    		      }	    
	    	  }	    		    
	    	});	    
	    this.mainframe1.getContentPane().setLayout(null);	    
	    this.l1 = new JLabel("A = ");
	    this.l1.setBounds(10, 30, 180, 30);
	    this.mainframe1.getContentPane().add(this.l1);
	    this.l2 = new JLabel("B = ");
	    this.l2.setBounds(10, 70, 180, 30);
	    this.mainframe1.getContentPane().add(this.l2);
	    this.l3 = new JLabel("Q1 = ");
	    this.l3.setBounds(10, 110, 180, 30);
	    this.mainframe1.getContentPane().add(this.l3);
	    this.l4 = new JLabel("Q2 = ");
	    this.l4.setBounds(10, 150, 180, 30);
	    this.mainframe1.getContentPane().add(this.l4);
	    this.l5 = new JLabel("I = ");
	    this.l5.setBounds(10, 190, 180, 30);
	    this.mainframe1.getContentPane().add(this.l5);	    
	    this.pp1 = new JTextPane();
	    this.pp1.setBounds(400, 0, 400, 400);
	    this.mainframe1.getContentPane().add(this.pp1);
	    this.mainframe1.setResizable(false);
  }  
  public static void main(String[] args) {}
}
